/* Validates every level: well-formed, not solved at start, solved by its
 * stored solution, and a couple of rule invariants. Run: node test/solve.test.js
 */
const { simulate, key } = require('../js/simulation.js');
const { LEVELS } = require('../js/levels.js');

let failures = 0;
function assert(cond, msg) {
  if (cond) {
    console.log('  ok  ' + msg);
  } else {
    failures++;
    console.error('  FAIL ' + msg);
  }
}

function objectsFor(level, placements) {
  // placements: array of {id, x, y, dir?} overriding movable start positions
  const byId = new Map((placements || []).map(p => [p.id, p]));
  const movables = level.movable.map(m => {
    const p = byId.get(m.id);
    return p ? { ...m, x: p.x, y: p.y, dir: p.dir !== undefined ? p.dir : m.dir } : { ...m };
  });
  return [...level.fixed.map(o => ({ ...o })), ...movables];
}

LEVELS.forEach((level, i) => {
  console.log(`Level ${i + 1}: ${level.name}`);

  // -- well-formedness
  const all = objectsFor(level, null);
  const seen = new Set();
  let overlap = false, oob = false;
  for (const o of all) {
    if (o.x < 0 || o.x >= level.cols || o.y < 0 || o.y >= level.rows) oob = true;
    const k = key(o.x, o.y);
    if (seen.has(k)) overlap = true;
    seen.add(k);
  }
  assert(!oob, 'all objects inside the grid');
  assert(!overlap, 'no two objects share a cell (start)');

  const solSeen = new Set(level.fixed.map(o => key(o.x, o.y)));
  let solOverlap = false;
  for (const p of level.solution) {
    const k = key(p.x, p.y);
    if (solSeen.has(k)) solOverlap = true;
    solSeen.add(k);
  }
  assert(!solOverlap, 'no two objects share a cell (solution)');
  assert(level.solution.length === level.movable.length ||
         level.solution.every(p => level.movable.some(m => m.id === p.id)),
         'solution ids match movables');

  // -- start position must not already win
  const start = simulate(level, all);
  assert(!start.win, 'start position does not win');

  // -- stored solution must win
  const solved = simulate(level, objectsFor(level, level.solution));
  assert(solved.win, 'solution wins');
  assert(!solved.looped, 'solution does not loop');
});

// -- rule invariants on a synthetic board ------------------------------------
console.log('Invariants');
{
  // Steam hitting a wheel must not turn it.
  const lvl = { cols: 3, rows: 4 };
  const objs = [
    { type: 'SPRING', x: 1, y: 0 },
    { type: 'BOILER', x: 1, y: 3 },
    { type: 'WHEEL', x: 1, y: 1 }, // sits in the steam column
  ];
  // water from spring (1,0) falls (1,1)? -> wheel is at (1,1): water hits it!
  // Use an offset spring instead.
  const objs2 = [
    { type: 'SPRING', x: 0, y: 0 },
    { type: 'RAMP', x: 0, y: 2, dir: 'R' },
    { type: 'BOILER', x: 1, y: 3 },
    { type: 'WHEEL', x: 1, y: 1 },
  ];
  const r = simulate(lvl, objs2);
  assert(!r.win, 'steam does not turn a wheel');
  assert(r.dissipations.length > 0, 'steam dissipates against the wheel');
}
{
  // A boiler->condenser->boiler cycle terminates (budget guard) and never wins.
  const lvl = { cols: 2, rows: 4 };
  const objs = [
    { type: 'SPRING', x: 0, y: 0 },
    { type: 'RAMP', x: 0, y: 2, dir: 'R' },
    { type: 'BOILER', x: 1, y: 3 },
    { type: 'CONDENSER', x: 1, y: 0 },
    { type: 'WHEEL', x: 0, y: 3 },
  ];
  const r = simulate(lvl, objs);
  assert(r.looped === true, 'condenser dripping back into the boiler is detected as a loop');
  assert(!r.win, 'a loop is not a win');
}
{
  // Water falling straight onto a flat top spills; with ramp momentum it runs.
  const lvl = { cols: 4, rows: 4 };
  const flat = simulate(lvl, [
    { type: 'SPRING', x: 1, y: 0 },
    { type: 'BLOCK', x: 1, y: 2 },
    { type: 'WHEEL', x: 3, y: 3 },
  ]);
  assert(flat.spills.length === 1 && !flat.win, 'straight fall onto a crate spills');
  const run = simulate(lvl, [
    { type: 'SPRING', x: 1, y: 0 },
    { type: 'RAMP', x: 1, y: 2, dir: 'R' },
    { type: 'BLOCK', x: 2, y: 3 },
    { type: 'WHEEL', x: 3, y: 3 },
  ]);
  assert(run.win, 'ramp momentum carries water across a crate into the wheel');
}

console.log(failures === 0 ? '\nAll checks passed.' : `\n${failures} check(s) FAILED.`);
process.exit(failures === 0 ? 0 : 1);
