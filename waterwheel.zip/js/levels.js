/* Waterwheel — level definitions.
 *
 * fixed:   objects the player cannot touch.
 * movable: objects the player can drag (and flip, for ramps); `id` ties a
 *          movable to its entry in `solution`.
 * solution: one known winning placement, used only by test/solve.test.js.
 */

const LEVELS = [
  {
    name: 'First Drops',
    hint: 'Drag the ramp under the stream so the water bends onto the wheel.',
    cols: 7, rows: 6,
    fixed: [
      { type: 'SPRING', x: 3, y: 0 },
      { type: 'WHEEL', x: 2, y: 5 },
    ],
    movable: [
      { id: 'r1', type: 'RAMP', x: 4, y: 4, dir: 'L' },
    ],
    solution: [
      { id: 'r1', x: 3, y: 4, dir: 'L' },
    ],
  },
  {
    name: 'Flip It',
    hint: 'Click a ramp to flip its direction. Chain two bends to reach the wheel.',
    cols: 8, rows: 6,
    fixed: [
      { type: 'SPRING', x: 2, y: 0 },
      { type: 'WHEEL', x: 4, y: 5 },
    ],
    movable: [
      { id: 'r1', type: 'RAMP', x: 2, y: 3, dir: 'L' },
      { id: 'r2', type: 'RAMP', x: 6, y: 2, dir: 'R' },
    ],
    solution: [
      { id: 'r1', x: 2, y: 3, dir: 'R' },
      { id: 'r2', x: 3, y: 4, dir: 'R' },
    ],
  },
  {
    name: 'Staircase',
    hint: 'Water runs along the top of rocks. Build a staircase down to the wheel.',
    cols: 10, rows: 7,
    fixed: [
      { type: 'SPRING', x: 1, y: 0 },
      { type: 'WHEEL', x: 6, y: 6 },
      { type: 'ROCK', x: 2, y: 3 },
      { type: 'ROCK', x: 3, y: 3 },
    ],
    movable: [
      { id: 'r1', type: 'RAMP', x: 8, y: 1, dir: 'L' },
      { id: 'r2', type: 'RAMP', x: 8, y: 3, dir: 'L' },
      { id: 'r3', type: 'RAMP', x: 8, y: 5, dir: 'L' },
    ],
    solution: [
      { id: 'r1', x: 1, y: 2, dir: 'R' },
      { id: 'r2', x: 4, y: 4, dir: 'R' },
      { id: 'r3', x: 5, y: 5, dir: 'R' },
    ],
  },
  {
    name: 'Plug the Hole',
    hint: 'Crates plug holes — running water crosses right over them.',
    cols: 10, rows: 7,
    fixed: [
      { type: 'SPRING', x: 2, y: 0 },
      { type: 'WHEEL', x: 6, y: 6 },
      { type: 'ROCK', x: 3, y: 4 },
      { type: 'ROCK', x: 5, y: 4 },
    ],
    movable: [
      { id: 'r1', type: 'RAMP', x: 2, y: 3, dir: 'L' },
      { id: 'b1', type: 'BLOCK', x: 8, y: 2 },
    ],
    solution: [
      { id: 'r1', x: 2, y: 3, dir: 'R' },
      { id: 'b1', x: 4, y: 4 },
    ],
  },
  {
    name: 'Full Steam',
    hint: 'The wheel is too high for water… but steam rises! Boil the water, then catch the steam with the condenser.',
    cols: 8, rows: 8,
    fixed: [
      { type: 'SPRING', x: 2, y: 4 },
      { type: 'RAMP', x: 2, y: 6, dir: 'R' },
      { type: 'BOILER', x: 3, y: 7 },
      { type: 'WHEEL', x: 4, y: 3 },
    ],
    movable: [
      { id: 'r1', type: 'RAMP', x: 6, y: 6, dir: 'L' },
      { id: 'c1', type: 'CONDENSER', x: 6, y: 2 },
    ],
    solution: [
      { id: 'r1', x: 3, y: 2, dir: 'L' },
      { id: 'c1', x: 4, y: 1 },
    ],
  },
  {
    name: 'Steam Bends',
    hint: 'Steam slides the other way along a ramp’s belly. Bend it twice to slip past the rocks.',
    cols: 10, rows: 8,
    fixed: [
      { type: 'SPRING', x: 1, y: 1 },
      { type: 'RAMP', x: 1, y: 6, dir: 'R' },
      { type: 'BOILER', x: 2, y: 7 },
      { type: 'ROCK', x: 2, y: 1 },
      { type: 'ROCK', x: 3, y: 1 },
      { type: 'WHEEL', x: 4, y: 4 },
    ],
    movable: [
      { id: 'r1', type: 'RAMP', x: 7, y: 6, dir: 'R' },
      { id: 'r2', type: 'RAMP', x: 8, y: 6, dir: 'R' },
      { id: 'c1', type: 'CONDENSER', x: 8, y: 2 },
    ],
    solution: [
      { id: 'r1', x: 2, y: 4, dir: 'L' },
      { id: 'r2', x: 3, y: 2, dir: 'L' },
      { id: 'c1', x: 4, y: 0 },
    ],
  },
  {
    name: 'Two Wheels',
    hint: 'Both wheels must turn at once. The crate bridges the gap in the shelf.',
    cols: 10, rows: 8,
    fixed: [
      { type: 'SPRING', x: 2, y: 0 },
      { type: 'SPRING', x: 7, y: 0 },
      { type: 'WHEEL', x: 6, y: 4 },
      { type: 'WHEEL', x: 4, y: 7 },
      { type: 'ROCK', x: 3, y: 3 },
      { type: 'ROCK', x: 5, y: 3 },
      { type: 'ROCK', x: 5, y: 6 },
      { type: 'ROCK', x: 6, y: 6 },
    ],
    movable: [
      { id: 'r1', type: 'RAMP', x: 1, y: 4, dir: 'L' },
      { id: 'r2', type: 'RAMP', x: 8, y: 4, dir: 'R' },
      { id: 'b1', type: 'BLOCK', x: 0, y: 6 },
    ],
    solution: [
      { id: 'r1', x: 2, y: 2, dir: 'R' },
      { id: 'r2', x: 7, y: 5, dir: 'L' },
      { id: 'b1', x: 4, y: 3 },
    ],
  },
  {
    name: 'The Great Machine',
    hint: 'Everything you’ve learned: a shelf to bridge, a boiler to feed, and steam to bend onto the high condenser.',
    cols: 12, rows: 9,
    fixed: [
      { type: 'SPRING', x: 2, y: 0 },
      { type: 'SPRING', x: 9, y: 0 },
      { type: 'ROCK', x: 3, y: 4 },
      { type: 'ROCK', x: 5, y: 4 },
      { type: 'BOILER', x: 8, y: 7 },
      { type: 'WHEEL', x: 6, y: 8 },
      { type: 'WHEEL', x: 7, y: 8 },
    ],
    movable: [
      { id: 'r1', type: 'RAMP', x: 0, y: 7, dir: 'R' },
      { id: 'b1', type: 'BLOCK', x: 0, y: 8 },
      { id: 'r3', type: 'RAMP', x: 11, y: 7, dir: 'R' },
      { id: 'r4', type: 'RAMP', x: 11, y: 8, dir: 'L' },
      { id: 'c1', type: 'CONDENSER', x: 5, y: 1 },
    ],
    solution: [
      { id: 'r1', x: 2, y: 3, dir: 'R' },
      { id: 'b1', x: 4, y: 4 },
      { id: 'r3', x: 9, y: 4, dir: 'L' },
      { id: 'r4', x: 8, y: 1, dir: 'R' },
      { id: 'c1', x: 7, y: 0 },
    ],
  },
];

if (typeof module !== 'undefined') {
  module.exports = { LEVELS };
}
