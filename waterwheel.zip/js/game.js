/* Waterwheel — game state, input and HUD. */
(() => {
  const canvas = document.getElementById('game');
  const levelBar = document.getElementById('level-bar');
  const levelName = document.getElementById('level-name');
  const levelHint = document.getElementById('level-hint');
  const winOverlay = document.getElementById('win-overlay');
  const winTitle = document.getElementById('win-title');
  const btnNext = document.getElementById('btn-next');
  const btnReplay = document.getElementById('btn-replay');
  const btnReset = document.getElementById('btn-reset');

  const STORAGE_KEY = 'waterwheel.unlocked';
  let unlocked = Math.max(1, parseInt(localStorage.getItem(STORAGE_KEY), 10) || 1);

  let levelIndex = 0;
  let level = null;
  let fixed = [];
  let movables = [];
  let movableSet = new Set();
  let sim = null;
  let revealStart = 0;
  let winTimer = null;
  let won = false;
  let drag = null;  // {obj, px, py, startX, startY, fromX, fromY, moved}
  let hover = null;

  Renderer.init(canvas);

  // ---- level lifecycle ------------------------------------------------------

  function loadLevel(i) {
    levelIndex = i;
    level = LEVELS[i];
    fixed = level.fixed.map(o => ({ ...o }));
    movables = level.movable.map(o => ({ ...o }));
    movableSet = new Set(movables);
    drag = null;
    won = false;
    winOverlay.classList.add('hidden');
    Renderer.setLevel(level);
    levelName.textContent = `Level ${i + 1} — ${level.name}`;
    levelHint.textContent = level.hint;
    updateLevelBar();
    resim();
  }

  function allObjects() { return [...fixed, ...movables]; }

  function resim() {
    sim = simulate(level, allObjects());
    revealStart = performance.now();
    clearTimeout(winTimer);
    if (sim.win) {
      const maxT = sim.segments.reduce((m, s) => Math.max(m, s.t), 0);
      winTimer = setTimeout(showWin, (maxT + 3) * Renderer.STEP_MS);
    }
  }

  function showWin() {
    won = true;
    const last = levelIndex === LEVELS.length - 1;
    const nWheels = level.fixed.filter(o => o.type === 'WHEEL').length;
    winTitle.textContent = last
      ? '✨ You built the Great Machine! ✨'
      : (nWheels > 1 ? 'The wheels turn!' : 'The wheel turns!');
    btnNext.style.display = last ? 'none' : '';
    winOverlay.classList.remove('hidden');
    unlocked = Math.max(unlocked, Math.min(LEVELS.length, levelIndex + 2));
    localStorage.setItem(STORAGE_KEY, String(unlocked));
    updateLevelBar();
  }

  // ---- HUD ------------------------------------------------------------------

  function updateLevelBar() {
    levelBar.innerHTML = '';
    LEVELS.forEach((lvl, i) => {
      const b = document.createElement('button');
      b.textContent = i + 1;
      b.title = lvl.name;
      if (i === levelIndex) b.classList.add('current');
      if (i + 1 < unlocked) b.classList.add('done');
      b.disabled = i + 1 > unlocked;
      b.addEventListener('click', () => loadLevel(i));
      levelBar.appendChild(b);
    });
  }

  btnReset.addEventListener('click', () => loadLevel(levelIndex));
  btnReplay.addEventListener('click', () => loadLevel(levelIndex));
  btnNext.addEventListener('click', () => loadLevel(Math.min(LEVELS.length - 1, levelIndex + 1)));

  // ---- input ------------------------------------------------------------------

  function occupiedCells(excludeObj) {
    const s = new Set();
    for (const o of allObjects()) {
      if (o !== excludeObj) s.add(o.x + ',' + o.y);
    }
    return s;
  }

  function movableAt(x, y) {
    return movables.find(o => o.x === x && o.y === y) || null;
  }

  canvas.addEventListener('pointerdown', (e) => {
    if (won) return;
    const c = Renderer.cellAt(e.clientX, e.clientY);
    const obj = movableAt(c.x, c.y);
    if (!obj) return;
    drag = {
      obj, px: c.px, py: c.py,
      startX: c.px, startY: c.py,
      fromX: obj.x, fromY: obj.y,
      moved: false,
    };
    hover = { x: c.x, y: c.y };
    canvas.setPointerCapture(e.pointerId);
    canvas.classList.add('grabbing');
  });

  canvas.addEventListener('pointermove', (e) => {
    const c = Renderer.cellAt(e.clientX, e.clientY);
    if (drag) {
      drag.px = c.px;
      drag.py = c.py;
      if (Math.hypot(c.px - drag.startX, c.py - drag.startY) > 8) drag.moved = true;
      hover = { x: c.x, y: c.y };
    } else {
      canvas.classList.toggle('grab', !won && !!movableAt(c.x, c.y));
    }
  });

  canvas.addEventListener('pointerup', (e) => {
    if (!drag) return;
    const c = Renderer.cellAt(e.clientX, e.clientY);
    const obj = drag.obj;
    const wasDrag = drag.moved;
    drag = null;
    hover = null;
    canvas.classList.remove('grabbing');

    if (!wasDrag) {
      // a simple click: flip ramps
      if (obj.type === 'RAMP') {
        obj.dir = obj.dir === 'L' ? 'R' : 'L';
        resim();
      }
      return;
    }
    const inside = c.x >= 0 && c.x < level.cols && c.y >= 0 && c.y < level.rows;
    const free = inside && !occupiedCells(obj).has(c.x + ',' + c.y);
    if (free) {
      obj.x = c.x;
      obj.y = c.y;
      resim();
    }
    // otherwise the object simply stays where it was (snap back)
  });

  canvas.addEventListener('pointercancel', () => {
    drag = null;
    hover = null;
    canvas.classList.remove('grabbing');
  });

  // ---- render loop ------------------------------------------------------------

  function frame() {
    Renderer.render({
      level,
      objects: allObjects(),
      movableSet,
      sim,
      revealStart,
      drag,
      hover,
      occupied: drag ? occupiedCells(drag.obj) : null,
    });
    requestAnimationFrame(frame);
  }

  loadLevel(0);
  requestAnimationFrame(frame);
})();
