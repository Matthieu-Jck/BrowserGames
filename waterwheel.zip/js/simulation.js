/* Waterwheel — pure flow simulation.
 *
 * Coordinates: x grows right, y grows down. y=0 is the top row.
 *
 * Flow rules:
 *   WATER falls. Landing on a RAMP throws it one cell sideways (the ramp's
 *   direction) and gives it momentum; while supported by something solid it
 *   keeps running sideways with that momentum. Falling straight onto a flat
 *   solid top (no momentum) spills. Touching a BOILER turns it to steam.
 *   Hitting a WHEEL makes the wheel turn.
 *   STEAM rises. A RAMP's underside throws it one cell sideways — opposite
 *   to the ramp's water direction. Touching a CONDENSER's underside (or side)
 *   condenses it: water drips from the condenser's bottom. Anything else
 *   solid, or the top of the grid, dissipates it.
 */

const T = {
  SPRING: 'SPRING',
  WHEEL: 'WHEEL',
  ROCK: 'ROCK',
  BLOCK: 'BLOCK',
  RAMP: 'RAMP',
  BOILER: 'BOILER',
  CONDENSER: 'CONDENSER',
};

function key(x, y) { return x + ',' + y; }

// Build a cell lookup from an object list [{type,x,y,dir}, ...]
function buildGrid(objects) {
  const grid = new Map();
  for (const o of objects) grid.set(key(o.x, o.y), o);
  return grid;
}

const DX = { L: -1, R: 1 };
function opposite(dir) { return dir === 'L' ? 'R' : 'L'; }

/**
 * Simulate all streams for a level given the current object placement.
 * @param {{cols:number, rows:number}} level
 * @param {Array<{type:string,x:number,y:number,dir?:string}>} objects
 * @returns {{segments:Array, wheelsHit:Set<string>, win:boolean,
 *            spills:Array, drains:Array, dissipations:Array, looped:boolean}}
 */
function simulate(level, objects) {
  const grid = buildGrid(objects);
  const cols = level.cols, rows = level.rows;
  const at = (x, y) => grid.get(key(x, y)) || null;
  const inGrid = (x, y) => x >= 0 && x < cols && y >= 0 && y < rows;

  const wheels = objects.filter(o => o.type === T.WHEEL);
  const springs = objects.filter(o => o.type === T.SPRING);

  const segments = [];      // {x, y, phase, enter, exit, t} for rendering
  const wheelsHit = new Set();
  const spills = [];        // {x, y, t} water dead-ends
  const drains = [];        // {x, y, t} water leaves the grid
  const dissipations = [];  // {x, y, t} steam ends
  let looped = false;

  let budget = cols * rows * 8;

  // Each front is processed fully before the next (they never interact).
  const queue = springs.map(s => ({
    phase: 'water', x: s.x, y: s.y, momentum: null, t: 0,
    enter: null, // side the stream entered the current cell from
  }));

  const seg = (f, exit) => segments.push({
    x: f.x, y: f.y, phase: f.phase, enter: f.enter, exit, t: f.t,
  });
  const moveTo = (f, x, y, enter) => { f.x = x; f.y = y; f.enter = enter; f.t++; };

  while (queue.length > 0) {
    const f = queue.shift();
    const visited = new Set();

    while (true) {
      if (budget-- <= 0) { looped = true; break; }
      const state = key(f.x, f.y) + ':' + f.phase + ':' + (f.momentum || '-');
      if (visited.has(state)) { looped = true; break; }
      visited.add(state);

      if (f.phase === 'water') {
        if (!stepWater(f)) break;
      } else {
        if (!stepSteam(f)) break;
      }
    }
  }

  // --- water ---------------------------------------------------------------
  // Returns true to continue stepping this front, false when it ended.
  function stepWater(f) {
    const bx = f.x, by = f.y + 1; // below
    if (!inGrid(bx, by)) {
      seg(f, 'S');
      drains.push({ x: f.x, y: f.y, t: f.t });
      return false;
    }
    const below = at(bx, by);
    if (!below) {
      seg(f, 'S');
      moveTo(f, bx, by, 'N');
      f.momentum = null; // falling kills sideways momentum
      return true;
    }
    if (below.type === T.WHEEL) {
      seg(f, 'S');
      wheelsHit.add(key(bx, by));
      segments.push({ x: bx, y: by, phase: 'water', enter: 'N', exit: null, t: f.t + 1 });
      return false;
    }
    if (below.type === T.BOILER) {
      seg(f, 'S');
      spawnSteam(below, f.t + 1);
      return false;
    }
    if (below.type === T.RAMP) {
      seg(f, 'S');
      moveTo(f, bx, by, 'N');
      return rampThrowWater(f, below.dir);
    }
    // solid top (ROCK, BLOCK, SPRING, CONDENSER)
    if (f.momentum) return runSideways(f, f.momentum);
    seg(f, null);
    spills.push({ x: f.x, y: f.y, t: f.t });
    return false;
  }

  // Water inside a ramp cell is forced out sideways, then keeps momentum.
  function rampThrowWater(f, dir) {
    f.momentum = dir;
    return runSideways(f, dir);
  }

  function runSideways(f, dir) {
    const tx = f.x + DX[dir], ty = f.y;
    const side = dir === 'L' ? 'W' : 'E';
    const fromSide = dir === 'L' ? 'E' : 'W';
    if (!inGrid(tx, ty)) {
      seg(f, side);
      drains.push({ x: f.x, y: f.y, t: f.t });
      return false;
    }
    const target = at(tx, ty);
    if (!target) {
      seg(f, side);
      moveTo(f, tx, ty, fromSide);
      return true;
    }
    if (target.type === T.WHEEL) {
      seg(f, side);
      wheelsHit.add(key(tx, ty));
      segments.push({ x: tx, y: ty, phase: 'water', enter: fromSide, exit: null, t: f.t + 1 });
      return false;
    }
    if (target.type === T.BOILER) {
      seg(f, side);
      spawnSteam(target, f.t + 1);
      return false;
    }
    if (target.type === T.RAMP && target.dir === dir) {
      seg(f, side);
      moveTo(f, tx, ty, fromSide);
      return rampThrowWater(f, target.dir);
    }
    // blocked sideways: pool & spill where we are
    seg(f, null);
    spills.push({ x: f.x, y: f.y, t: f.t });
    return false;
  }

  function spawnSteam(boiler, t) {
    queue.push({ phase: 'steam', x: boiler.x, y: boiler.y, momentum: null, t, enter: null });
  }

  function spawnWater(condenser, t) {
    queue.push({ phase: 'water', x: condenser.x, y: condenser.y, momentum: null, t, enter: null });
  }

  // --- steam ---------------------------------------------------------------
  function stepSteam(f) {
    const ax = f.x, ay = f.y - 1; // above
    if (!inGrid(ax, ay)) {
      seg(f, 'N');
      dissipations.push({ x: f.x, y: f.y, t: f.t });
      return false;
    }
    const above = at(ax, ay);
    if (!above) {
      seg(f, 'N');
      moveTo(f, ax, ay, 'S');
      return true;
    }
    if (above.type === T.CONDENSER) {
      seg(f, 'N');
      spawnWater(above, f.t + 1);
      return false;
    }
    if (above.type === T.RAMP) {
      seg(f, 'N');
      moveTo(f, ax, ay, 'S');
      return rampThrowSteam(f, opposite(above.dir));
    }
    // flat underside (ROCK, BLOCK, SPRING, BOILER, WHEEL)
    seg(f, null);
    dissipations.push({ x: f.x, y: f.y, t: f.t });
    return false;
  }

  // Steam under a ramp slides one cell sideways, then rises again.
  function rampThrowSteam(f, dir) {
    const tx = f.x + DX[dir], ty = f.y;
    const side = dir === 'L' ? 'W' : 'E';
    const fromSide = dir === 'L' ? 'E' : 'W';
    if (!inGrid(tx, ty)) {
      seg(f, side);
      dissipations.push({ x: f.x, y: f.y, t: f.t });
      return false;
    }
    const target = at(tx, ty);
    if (!target) {
      seg(f, side);
      moveTo(f, tx, ty, fromSide);
      return true;
    }
    if (target.type === T.CONDENSER) {
      seg(f, side);
      spawnWater(target, f.t + 1);
      return false;
    }
    if (target.type === T.RAMP && opposite(target.dir) === dir) {
      seg(f, side);
      moveTo(f, tx, ty, fromSide);
      return rampThrowSteam(f, dir);
    }
    seg(f, null);
    dissipations.push({ x: f.x, y: f.y, t: f.t });
    return false;
  }

  const win = wheels.length > 0 && wheels.every(w => wheelsHit.has(key(w.x, w.y)));
  return { segments, wheelsHit, win, spills, drains, dissipations, looped };
}

if (typeof module !== 'undefined') {
  module.exports = { simulate, T, key, buildGrid };
}
