/* Waterwheel — canvas renderer. Pure drawing: game.js owns state and calls
 * Renderer.render() every frame. */

const Renderer = (() => {
  const CELL = 64;
  const STEP_MS = 110; // stream reveal speed: one cell per STEP_MS

  let canvas, ctx, dpr = 1;
  let level = null;

  // animation state
  const wheels = new Map(); // "x,y" -> {angle, speed}
  let lastNow = 0;
  let cachedSim = null;
  let cachedPaths = null;     // segment polylines for the current sim
  let cachedHitTimes = null;  // wheel key -> reveal step at which it is hit

  function init(c) {
    canvas = c;
    ctx = canvas.getContext('2d');
    dpr = window.devicePixelRatio || 1;
  }

  function setLevel(lvl) {
    level = lvl;
    canvas.width = lvl.cols * CELL * dpr;
    canvas.height = lvl.rows * CELL * dpr;
    canvas.style.aspectRatio = `${lvl.cols} / ${lvl.rows}`;
    wheels.clear();
    cachedSim = null;
  }

  function cellAt(clientX, clientY) {
    const r = canvas.getBoundingClientRect();
    const lx = (clientX - r.left) * (level.cols * CELL) / r.width;
    const ly = (clientY - r.top) * (level.rows * CELL) / r.height;
    return { px: lx, py: ly, x: Math.floor(lx / CELL), y: Math.floor(ly / CELL) };
  }

  // ---- stream geometry ------------------------------------------------------

  function sidePoint(x, y, side) {
    switch (side) {
      case 'N': return [(x + 0.5) * CELL, y * CELL];
      case 'S': return [(x + 0.5) * CELL, (y + 1) * CELL];
      case 'E': return [(x + 1) * CELL, (y + 0.5) * CELL];
      case 'W': return [x * CELL, (y + 0.5) * CELL];
      default: return [(x + 0.5) * CELL, (y + 0.5) * CELL];
    }
  }

  function buildPaths(sim, objects) {
    const byCell = new Map(objects.map(o => [o.x + ',' + o.y, o]));
    return sim.segments.map(seg => {
      const obj = byCell.get(seg.x + ',' + seg.y);
      const a = sidePoint(seg.x, seg.y, seg.enter);
      const b = sidePoint(seg.x, seg.y, seg.exit);
      let elbow;
      if (obj && obj.type === 'RAMP') {
        // ride the ramp surface (water) / its belly (steam)
        elbow = [(seg.x + 0.5) * CELL, (seg.y + (seg.phase === 'water' ? 0.68 : 0.85)) * CELL];
      } else if (seg.enter && seg.exit && seg.enter !== oppositeSide(seg.exit)) {
        elbow = [(seg.x + 0.5) * CELL, (seg.y + 0.5) * CELL];
      }
      const pts = elbow ? [a, elbow, b] : [a, b];
      let len = 0;
      for (let i = 1; i < pts.length; i++) {
        len += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
      }
      return { pts, len, seg };
    });
  }

  function oppositeSide(s) {
    return { N: 'S', S: 'N', E: 'W', W: 'E' }[s] || null;
  }

  function partialPath(pts, frac) {
    if (frac >= 1) return pts;
    let total = 0;
    const lens = [];
    for (let i = 1; i < pts.length; i++) {
      const l = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
      lens.push(l);
      total += l;
    }
    let remain = total * frac;
    const out = [pts[0]];
    for (let i = 1; i < pts.length; i++) {
      if (remain >= lens[i - 1]) {
        out.push(pts[i]);
        remain -= lens[i - 1];
      } else {
        const t = lens[i - 1] === 0 ? 0 : remain / lens[i - 1];
        out.push([
          pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * t,
          pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * t,
        ]);
        break;
      }
    }
    return out;
  }

  // ---- main render ----------------------------------------------------------

  function render(state) {
    const now = performance.now();
    const dt = Math.min(50, now - lastNow) / 1000;
    lastNow = now;

    const { sim, objects, revealStart, drag, hover } = state;
    if (sim !== cachedSim) {
      cachedSim = sim;
      cachedPaths = buildPaths(sim, objects);
      cachedHitTimes = new Map();
      for (const s of sim.segments) {
        if (s.exit === null && sim.wheelsHit.has(s.x + ',' + s.y)) {
          const k = s.x + ',' + s.y;
          if (!cachedHitTimes.has(k) || s.t < cachedHitTimes.get(k)) cachedHitTimes.set(k, s.t);
        }
      }
    }
    const revealT = (now - revealStart) / STEP_MS;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawBackground(now);
    if (drag) drawDropTargets(state);

    // streams go under the objects so they look carved into the scene
    drawStreams(revealT, now);
    drawEndEffects(revealT, now);

    for (const o of objects) {
      if (drag && o === drag.obj) continue;
      drawObject(o, now, dt, {
        movable: state.movableSet.has(o),
        revealT,
      });
    }

    if (drag) {
      ctx.save();
      ctx.globalAlpha = 0.85;
      ctx.translate(drag.px - CELL / 2, drag.py - CELL / 2);
      ctx.scale(1.05, 1.05);
      drawObjectShape(drag.obj, 0, 0, now);
      ctx.restore();
    }
  }

  function drawBackground(now) {
    const w = level.cols * CELL, h = level.rows * CELL;
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, '#27374e');
    g.addColorStop(1, '#16202e');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = 'rgba(255,255,255,0.045)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 1; x < level.cols; x++) { ctx.moveTo(x * CELL, 0); ctx.lineTo(x * CELL, h); }
    for (let y = 1; y < level.rows; y++) { ctx.moveTo(0, y * CELL); ctx.lineTo(w, y * CELL); }
    ctx.stroke();
  }

  function drawDropTargets(state) {
    const { occupied, drag, hover } = state;
    for (let x = 0; x < level.cols; x++) {
      for (let y = 0; y < level.rows; y++) {
        const free = !occupied.has(x + ',' + y);
        if (!free) continue;
        ctx.fillStyle = 'rgba(79,195,247,0.07)';
        ctx.fillRect(x * CELL + 2, y * CELL + 2, CELL - 4, CELL - 4);
      }
    }
    if (hover && hover.x >= 0 && hover.x < level.cols && hover.y >= 0 && hover.y < level.rows) {
      const free = !state.occupied.has(hover.x + ',' + hover.y);
      ctx.strokeStyle = free ? 'rgba(105,240,174,0.9)' : 'rgba(255,82,82,0.9)';
      ctx.lineWidth = 2.5;
      roundRect(hover.x * CELL + 3, hover.y * CELL + 3, CELL - 6, CELL - 6, 8);
      ctx.stroke();
    }
  }

  // ---- streams --------------------------------------------------------------

  function drawStreams(revealT, now) {
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    for (const phase of ['water', 'steam']) {
      const parts = [];
      for (const p of cachedPaths) {
        if (p.seg.phase !== phase) continue;
        const frac = Math.min(1, Math.max(0, revealT - p.seg.t));
        if (frac <= 0) continue;
        parts.push(partialPath(p.pts, frac));
      }
      if (parts.length === 0) continue;

      const stroke = (color, width, dash, offset) => {
        ctx.strokeStyle = color;
        ctx.lineWidth = width;
        ctx.setLineDash(dash || []);
        ctx.lineDashOffset = offset || 0;
        ctx.beginPath();
        for (const pts of parts) {
          ctx.moveTo(pts[0][0], pts[0][1]);
          for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
        }
        ctx.stroke();
        ctx.setLineDash([]);
      };

      if (phase === 'water') {
        stroke('rgba(21,101,192,0.95)', 13);
        stroke('rgba(66,165,245,0.95)', 7);
        stroke('rgba(187,222,251,0.8)', 2.5, [10, 14], -now / 18);
      } else {
        stroke('rgba(207,216,220,0.30)', 15);
        stroke('rgba(255,255,255,0.35)', 8, [4, 16], -now / 28);
      }
    }
  }

  function drawEndEffects(revealT, now) {
    if (!cachedSim) return;
    for (const s of cachedSim.spills) {
      if (revealT < s.t + 1) continue;
      const cx = (s.x + 0.5) * CELL, cy = (s.y + 0.78) * CELL;
      ctx.fillStyle = 'rgba(66,165,245,0.55)';
      ctx.beginPath();
      ctx.ellipse(cx, cy + 6, 16 + Math.sin(now / 300) * 2, 5, 0, 0, Math.PI * 2);
      ctx.fill();
      for (let i = 0; i < 3; i++) {
        const ph = ((now / 600) + i / 3) % 1;
        ctx.globalAlpha = 1 - ph;
        ctx.fillStyle = '#90caf9';
        ctx.beginPath();
        ctx.arc(cx + (i - 1) * 9, cy + ph * 14, 2.4, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }
    for (const d of cachedSim.dissipations) {
      if (revealT < d.t + 1) continue;
      const cx = (d.x + 0.5) * CELL, cy = (d.y + 0.3) * CELL;
      for (let i = 0; i < 3; i++) {
        const ph = ((now / 900) + i / 3) % 1;
        ctx.globalAlpha = (1 - ph) * 0.5;
        ctx.fillStyle = '#eceff1';
        ctx.beginPath();
        ctx.arc(cx + Math.sin((ph + i) * 6) * 8, cy - ph * 16, 4 + ph * 5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }
  }

  // ---- objects --------------------------------------------------------------

  function drawObject(o, now, dt, opts) {
    const px = o.x * CELL, py = o.y * CELL;
    if (opts.movable) {
      ctx.save();
      ctx.shadowColor = 'rgba(79,195,247,0.9)';
      ctx.shadowBlur = 10 + Math.sin(now / 400) * 3;
      drawObjectShape(o, px, py, now, dt, opts);
      ctx.restore();
      ctx.strokeStyle = 'rgba(178,235,242,0.5)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([5, 5]);
      roundRect(px + 2.5, py + 2.5, CELL - 5, CELL - 5, 9);
      ctx.stroke();
      ctx.setLineDash([]);
    } else {
      drawObjectShape(o, px, py, now, dt, opts);
    }
  }

  function drawObjectShape(o, px, py, now, dt = 0, opts = {}) {
    switch (o.type) {
      case 'ROCK': return drawRock(px, py);
      case 'BLOCK': return drawBlock(px, py);
      case 'RAMP': return drawRamp(px, py, o.dir);
      case 'SPRING': return drawSpring(px, py, now);
      case 'WHEEL': return drawWheel(o, px, py, now, dt, opts);
      case 'BOILER': return drawBoiler(px, py, now);
      case 'CONDENSER': return drawCondenser(px, py);
    }
  }

  function drawRock(px, py) {
    ctx.fillStyle = '#4e5a6b';
    ctx.beginPath();
    ctx.moveTo(px + 6, py + CELL - 4);
    ctx.lineTo(px + 3, py + CELL * 0.45);
    ctx.lineTo(px + CELL * 0.3, py + 8);
    ctx.lineTo(px + CELL * 0.75, py + 5);
    ctx.lineTo(px + CELL - 4, py + CELL * 0.4);
    ctx.lineTo(px + CELL - 6, py + CELL - 4);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.08)';
    ctx.beginPath();
    ctx.moveTo(px + CELL * 0.3, py + 8);
    ctx.lineTo(px + CELL * 0.75, py + 5);
    ctx.lineTo(px + CELL * 0.6, py + CELL * 0.35);
    ctx.closePath();
    ctx.fill();
  }

  function drawBlock(px, py) {
    ctx.fillStyle = '#8d6e44';
    roundRect(px + 4, py + 4, CELL - 8, CELL - 8, 6);
    ctx.fill();
    ctx.strokeStyle = '#5d4527';
    ctx.lineWidth = 3;
    roundRect(px + 4, py + 4, CELL - 8, CELL - 8, 6);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(px + 8, py + 8); ctx.lineTo(px + CELL - 8, py + CELL - 8);
    ctx.moveTo(px + CELL - 8, py + 8); ctx.lineTo(px + 8, py + CELL - 8);
    ctx.lineWidth = 2.5;
    ctx.stroke();
  }

  function drawRamp(px, py, dir) {
    ctx.fillStyle = '#a1887f';
    ctx.beginPath();
    if (dir === 'R') { // water slides to the right, down the TL->BR slope
      ctx.moveTo(px + 4, py + 6);
      ctx.lineTo(px + CELL - 4, py + CELL - 4);
      ctx.lineTo(px + 4, py + CELL - 4);
    } else {
      ctx.moveTo(px + CELL - 4, py + 6);
      ctx.lineTo(px + 4, py + CELL - 4);
      ctx.lineTo(px + CELL - 4, py + CELL - 4);
    }
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#6d4c41';
    ctx.lineWidth = 2.5;
    ctx.stroke();
    // arrow showing flow direction for water
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    ctx.font = 'bold 13px system-ui';
    ctx.textAlign = 'center';
    ctx.fillText(dir === 'R' ? '▸' : '◂', px + CELL / 2 + (dir === 'R' ? -8 : 8), py + CELL - 12);
  }

  function drawSpring(px, py, now) {
    ctx.fillStyle = '#546e7a';
    roundRect(px + 6, py + 4, CELL - 12, CELL * 0.55, 7);
    ctx.fill();
    ctx.fillStyle = '#37474f';
    ctx.fillRect(px + CELL * 0.38, py + CELL * 0.45, CELL * 0.24, CELL * 0.4);
    // mouth + welling water
    ctx.fillStyle = '#42a5f5';
    const bulge = 3 + Math.sin(now / 250) * 1.5;
    ctx.beginPath();
    ctx.ellipse(px + CELL / 2, py + CELL * 0.85, CELL * 0.12 + bulge * 0.3, bulge, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#b0bec5';
    ctx.font = 'bold 11px system-ui';
    ctx.textAlign = 'center';
    ctx.fillText('SPRING', px + CELL / 2, py + CELL * 0.3);
  }

  function drawWheel(o, px, py, now, dt, opts) {
    const k = o.x + ',' + o.y;
    let w = wheels.get(k);
    if (!w) { w = { angle: 0, speed: 0 }; wheels.set(k, w); }
    const hitT = cachedHitTimes ? cachedHitTimes.get(k) : undefined;
    const turning = hitT !== undefined && opts.revealT >= hitT;
    w.speed += ((turning ? 1 : 0) - w.speed) * Math.min(1, dt * 4);
    w.angle += w.speed * dt * 3.2;

    const cx = px + CELL / 2, cy = py + CELL / 2, r = CELL * 0.44;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(w.angle);
    ctx.strokeStyle = turning ? '#ffd54f' : '#90a4ae';
    ctx.fillStyle = 'rgba(38,50,56,0.85)';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    // paddles
    ctx.lineWidth = 3.5;
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
      ctx.stroke();
      const pa = a + 0.45;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
      ctx.lineTo(Math.cos(pa) * r * 0.82, Math.sin(pa) * r * 0.82);
      ctx.stroke();
    }
    ctx.fillStyle = turning ? '#ffd54f' : '#90a4ae';
    ctx.beginPath();
    ctx.arc(0, 0, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    if (w.speed > 0.2) { // sparkle when spinning
      ctx.fillStyle = `rgba(255,213,79,${0.25 * w.speed})`;
      ctx.beginPath();
      ctx.arc(cx, cy, r + 6, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function drawBoiler(px, py, now) {
    ctx.fillStyle = '#37474f';
    roundRect(px + 5, py + 6, CELL - 10, CELL - 10, 7);
    ctx.fill();
    ctx.strokeStyle = '#263238';
    ctx.lineWidth = 3;
    roundRect(px + 5, py + 6, CELL - 10, CELL - 10, 7);
    ctx.stroke();
    // firebox
    const flick = Math.sin(now / 90) * 2 + Math.sin(now / 47) * 1.5;
    ctx.fillStyle = '#ff7043';
    ctx.beginPath();
    ctx.moveTo(px + 16, py + CELL - 12);
    ctx.quadraticCurveTo(px + CELL * 0.35, py + CELL * 0.45 + flick, px + CELL / 2, py + CELL - 12);
    ctx.quadraticCurveTo(px + CELL * 0.65, py + CELL * 0.5 - flick, px + CELL - 16, py + CELL - 12);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#ffd54f';
    ctx.beginPath();
    ctx.ellipse(px + CELL / 2, py + CELL - 16, 8, 5 + flick * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#eceff1';
    ctx.font = 'bold 10px system-ui';
    ctx.textAlign = 'center';
    ctx.fillText('BOILER', px + CELL / 2, py + 19);
  }

  function drawCondenser(px, py) {
    ctx.fillStyle = '#78909c';
    roundRect(px + 5, py + 8, CELL - 10, CELL * 0.55, 7);
    ctx.fill();
    ctx.strokeStyle = '#455a64';
    ctx.lineWidth = 2.5;
    roundRect(px + 5, py + 8, CELL - 10, CELL * 0.55, 7);
    ctx.stroke();
    // cooling fins underneath
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let i = 0; i < 4; i++) {
      const fx = px + 14 + i * 12;
      ctx.moveTo(fx, py + CELL * 0.62);
      ctx.lineTo(fx, py + CELL * 0.85);
    }
    ctx.stroke();
    ctx.fillStyle = '#42a5f5';
    ctx.beginPath();
    ctx.arc(px + CELL / 2, py + CELL * 0.92, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#eceff1';
    ctx.font = 'bold 9px system-ui';
    ctx.textAlign = 'center';
    ctx.fillText('CONDENSER', px + CELL / 2, py + 24);
  }

  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  return { init, setLevel, render, cellAt, CELL, STEP_MS };
})();

if (typeof module !== 'undefined') {
  module.exports = { Renderer };
}
