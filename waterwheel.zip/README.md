# 💧 Waterwheel

A browser logic-puzzle game: water pours from a spring and falls under gravity.
Drag the glowing pieces — ramps, crates, condensers — to steer the stream onto
the waterwheel and make it turn.

There is no inventory: every level already contains all of its pieces, just in
the wrong places.

## Play

Open `index.html` in any modern browser, or serve the folder statically:

```sh
python3 -m http.server
# then visit http://localhost:8000
```

No build step, no dependencies.

## How it works

- **Water falls.** A ramp throws it sideways and gives it momentum; while
  something solid supports it, it keeps running sideways. Falling straight onto
  a flat top makes it spill.
- **Crates** are movable solids — plug a hole and running water crosses right
  over it.
- **Boilers** turn water into **steam — which rises**. A ramp's underside bends
  steam sideways (the opposite way to water). A **condenser** turns steam back
  into water, dripping from its bottom.
- A wheel turns when **water** hits it (steam won't do). Turn every wheel to
  win the level.

8 levels, from a one-move tutorial to a machine that needs every mechanic.
Progress is saved in `localStorage`. Click a ramp to flip its direction.

## Development

The flow simulation (`js/simulation.js`) is pure and runs in Node too. Every
level ships with a known solution that the test suite replays:

```sh
npm test   # or: node test/solve.test.js
```

It asserts each level is well-formed, not solved at its start position, and
solved by its stored solution — plus a few rule invariants (steam never turns
a wheel, boiler/condenser loops terminate, momentum carries water over crates).
